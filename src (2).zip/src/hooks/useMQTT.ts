import { Client, Message } from 'paho-mqtt';
import { useCallback, useRef } from 'react';
import { useAppStore } from '../store/useAppStore';

// ── Bundled cloud broker config ──────────────────────────────────────
// These are the ONLY broker details that exist anywhere in the app.
// The user never sees or enters them — that's the whole point of
// moving off a local Mosquitto instance onto a fixed-hostname cloud
// broker (HiveMQ Cloud Serverless / EMQX Cloud Serverless).
//
// Port 8884 is WebSocket-over-TLS (WSS) — the counterpart to the
// firmware's port 8883 (MQTT-over-TLS / TCP) used by the ESP32s.
const BROKER_HOST = '623d305166fb450c91b63a979fe64ed9.s1.eu.hivemq.cloud'; // ← replace with your cluster URL
const BROKER_PORT = 8884;
const BROKER_PATH = '/mqtt';
const BROKER_USERNAME = 'jaytiwari'; // ← replace
const BROKER_PASSWORD = 'Jaytiwari@2003'; // ← replace

const PRESENCE_TOPIC_RE = /^room\/([^/]+)\/mmwave$/;
const STATUS_TOPIC_RE = /^room\/([^/]+)\/switch\/([^/]+)\/status$/;

const RECONNECT_DELAY_MS = 3000;
const PENDING_TIMEOUT_MS = 5000; // ESP-NOW isn't 100% reliable — stop
// showing "pending" if no confirmation
// ever arrives, rather than spinning forever.

export function useMQTT() {
  const clientRef = useRef<Client | null>(null);
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleMessage = useCallback((message: Message) => {
    const topic = message.destinationName;
    const raw = message.payloadString;

    let payload: any;
    try {
      payload = JSON.parse(raw);
    } catch {
      payload = {};
    }

    const presenceMatch = topic.match(PRESENCE_TOPIC_RE);
    if (presenceMatch) {
      const deviceId = presenceMatch[1];
      const presence = payload.presence === true || payload.presence === 1 || payload.presence === '1';
      useAppStore.getState().setDevicePresence(deviceId, presence);
      return;
    }

    const statusMatch = topic.match(STATUS_TOPIC_RE);
    if (statusMatch) {
      const switchId = statusMatch[2];
      const isOn = payload.on === true || payload.state === 'on';
      useAppStore.getState().setSwitchConfirmed(switchId, isOn);
    }
  }, []);

  const connect = useCallback(() => {
    const clientId = 'app_' + Math.random().toString(16).slice(2, 10);
    const client = new Client(BROKER_HOST, BROKER_PORT, BROKER_PATH, clientId);
    clientRef.current = client;

    client.onMessageArrived = handleMessage;

    client.onConnectionLost = () => {
      useAppStore.getState().setConnected(false);
      const { autoReconnect } = useAppStore.getState();
      if (autoReconnect && !reconnectTimer.current) {
        reconnectTimer.current = setTimeout(() => {
          reconnectTimer.current = null;
          connect();
        }, RECONNECT_DELAY_MS);
      }
    };

    client.connect({
      useSSL: true,
      userName: BROKER_USERNAME,
      password: BROKER_PASSWORD,
      onSuccess: () => {
        useAppStore.getState().setConnected(true);
        client.subscribe('room/+/mmwave');
        client.subscribe('room/+/switch/+/status');
      },
      onFailure: () => {
        useAppStore.getState().setConnected(false);
        const { autoReconnect } = useAppStore.getState();
        if (autoReconnect && !reconnectTimer.current) {
          reconnectTimer.current = setTimeout(() => {
            reconnectTimer.current = null;
            connect();
          }, RECONNECT_DELAY_MS);
        }
      },
    });
  }, [handleMessage]);

  const disconnect = useCallback(() => {
    if (reconnectTimer.current) {
      clearTimeout(reconnectTimer.current);
      reconnectTimer.current = null;
    }
    if (clientRef.current?.isConnected()) {
      clientRef.current.disconnect();
    }
    useAppStore.getState().setConnected(false);
  }, []);

  // Publishes {"cmd":"on"|"off"} to room/{deviceId}/switch/{switchId}/cmd.
  // The toggle does NOT flip to the new state here — it goes "pending"
  // and only shows the new state once the Switch ESP32's confirmation
  // comes back over the ESP-NOW return path and arrives as a /status
  // message, handled in handleMessage above.
  const publishSwitchCommand = useCallback((deviceId: string, switchId: string, on: boolean) => {
    const client = clientRef.current;
    if (!client?.isConnected()) return;

    useAppStore.getState().setSwitchPending(switchId, true);

    const message = new Message(JSON.stringify({ cmd: on ? 'on' : 'off' }));
    message.destinationName = `room/${deviceId}/switch/${switchId}/cmd`;
    client.send(message);

    setTimeout(() => {
      const current = useAppStore.getState().switches.find((s) => s.id === switchId);
      if (current?.pending) {
        useAppStore.getState().setSwitchPending(switchId, false);
      }
    }, PENDING_TIMEOUT_MS);
  }, []);

  return { connect, disconnect, publishSwitchCommand };
}
